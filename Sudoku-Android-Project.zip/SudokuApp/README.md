# Sudoku (Android)
Push this folder to a GitHub repo. The "Build APK" action builds it; download the
"Sudoku-APK" artifact from the finished run (Actions tab), unzip, install app-debug.apk.
